-------------------------------------------------------------------------------
-- Author       Fabio Augusto Pereira
-- Created      04/07/2021
-- Purpose      Create a Star Schema on Snowflake
-- Copyright ©2021
-------------------------------------------------------------------------------
-- Modification History
--
-- 05/07/20201  Fabio Augusto Pereira
--      DDL Script to create database Objects

USE DATABASE YELP_REVIEW_DATABASE;
USE SCHEMA DATAWAREHOUSE;

---------------------------------------------------------------------
-- Create Dimensional Table Temperature 
---------------------------------------------------------------------
CREATE OR REPLACE TABLE DIM_Temperature (
   Date_t date,
   Min_t number,
   Max_t number,
   Normal_min float,
   Normal_max float,
   CONSTRAINT pk_date_t PRIMARY KEY(Date_t)
);

INSERT INTO DIM_Temperature
SELECT DISTINCT DATE_T,MIN_T,MAX_T, Normal_MIN,Normal_MAX
FROM YELP_REVIEW_DATABASE.ODS.Temperature;


---------------------------------------------------------------------
-- Create Dimensional Table Precipitation
---------------------------------------------------------------------
CREATE OR REPLACE TABLE DIM_Precipitation (
date_p date,
precipitation float,
precipitation_normal float,
constraint pk_date_p primary key(date_p)
);

---------------------------------------------------------------------
--  Create Dimensional Table Business
---------------------------------------------------------------------

CREATE OR REPLACE TABLE DIM_Business(
business_id string,
name string,
address string,
postal_code string,
city string,
state string,
CONSTRAINT pk_business_id PRIMARY KEY(business_id)
);

---------------------------------------------------------------------
-- Create Dimensional Table Users
---------------------------------------------------------------------
CREATE OR REPLACE TABLE DIM_USERS(
  user_id String,
  name String,
  yelping_since Date,
  CONSTRAINT pk_user_id PRIMARY KEY(user_id)
);

---------------------------------------------------------------------
-- Create Fact Table for Reviews
---------------------------------------------------------------------

CREATE OR REPLACE TABLE Fact_Review (
   Review_id String,
   Business_Id String,
   User_id String,
   Date_Temperature Date,
   Date_Precipitation Date,
   Starts number,
   User_review_count number,
   Business_review_count number
)

---------------------------------------------------------------------
-- Load Table Covid
---------------------------------------------------------------------
INSERT INTO covid_features
SELECT
sequence_covid_identity.nextval,
parse_json($1):business_id,
parse_json($1):"Virtual Services Offered",
parse_json($1):"Delivery or Takeout",
parse_json($1):"Temporary Closed Until",
parse_json($1):"Call To Action enabled",
parse_json($1):"Request a Quote Enabled" ,
parse_json($1):"Grubhub enabled",
parse_json($1):"Covid Banner",
parse_json($1):"Highlights"
FROM YELP_REVIEW_DATABASE.STAGING.covid_features;

---------------------------------------------------------------------
-- Load Table Reviews
---------------------------------------------------------------------
INSERT INTO Reviews
SELECT
parse_json($1):business_id,
parse_json($1):review_id,
parse_json($1):user_id,
parse_json($1):date,
parse_json($1):stars,
parse_json($1):funny,
parse_json($1):cool,
parse_json($1):useful,
parse_json($1):text
FROM YELP_REVIEW_DATABASE.STAGING.Review;